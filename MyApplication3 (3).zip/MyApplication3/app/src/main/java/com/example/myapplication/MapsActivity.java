package com.example.myapplication;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private LocationListener locationListener;
    private LocationManager locationManager;

    private final long MIN_TIME = 1000;
    private final long MIN_DIST = 5;

    private LatLng latLng;

    double RADIUS = 500;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_COARSE_LOCATION}, PackageManager.PERMISSION_GRANTED);


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(final Location location) {
                Button btn = (Button) findViewById(R.id.addRadius);
                Button btn2 = (Button) findViewById(R.id.minusRadius);
                ImageButton btn3 = (ImageButton) findViewById(R.id.search);
                final float results[] = new float[2];

                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(RADIUS < 1000) {
                            RADIUS += 50;
                            Toast.makeText(getApplicationContext(), "The radius: " + RADIUS, Toast.LENGTH_SHORT).show();
                            mMap.clear();
                            try {
//
                                latLng = new LatLng(location.getLatitude(), location.getLongitude());
                                mMap.addMarker(new MarkerOptions().position(latLng).title("Marker"));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,13.2f));
                                mMap.addCircle(new CircleOptions().center(latLng).radius(RADIUS).strokeWidth(3F).strokeColor(Color.RED).fillColor(Color.argb(70, 150, 150, 50)));
                                LatLng sydney = new LatLng(37.4142744,-122.07959771);
                                mMap.addMarker(new MarkerOptions().position(sydney).title("Person 2"));
//                                mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                            } catch (SecurityException e) {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Max radius limit reached " + RADIUS , Toast.LENGTH_SHORT).show();

                        }
                        mMap.addCircle(new CircleOptions().center(latLng).radius(RADIUS).strokeWidth(3F).strokeColor(Color.RED).fillColor(Color.argb(70,150,150,50)));

                    }
                });
                btn2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(RADIUS > 100) {


                            RADIUS -= 50;
                            Toast.makeText(getApplicationContext(), "The radius: " + RADIUS, Toast.LENGTH_SHORT).show();
                            mMap.clear();
                            try {
//
                                latLng = new LatLng(location.getLatitude(), location.getLongitude());
                                mMap.addMarker(new MarkerOptions().position(latLng).title("Marker"));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,13.2f));
                                mMap.addCircle(new CircleOptions().center(latLng).radius(RADIUS).strokeWidth(3F).strokeColor(Color.RED).fillColor(Color.argb(70, 150, 150, 50)));
                                LatLng sydney = new LatLng(37.4142744,-122.07959771);
                                mMap.addMarker(new MarkerOptions().position(sydney).title("Person 2"));
//                                mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                            } catch (SecurityException e) {
                                e.printStackTrace();
                            }
                        }
                        else
                            {
                                Toast.makeText(getApplicationContext(), "Min radius limit reached " + RADIUS, Toast.LENGTH_SHORT).show();

                            }

                        mMap.addCircle(new CircleOptions().center(latLng).radius(RADIUS).strokeWidth(3F).strokeColor(Color.RED).fillColor(Color.argb(70,150,150,50)));

                    }
                });
                btn3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Location.distanceBetween(location.getLatitude(),location.getLongitude(), 37.4142744, -122.07959771, results);
                        if(RADIUS > results[0])
                        {
                            Toast.makeText(getApplicationContext(), "1 Buddy found " + results[0] + "m away", Toast.LENGTH_SHORT).show();
                        }
                        else
                            {
                            Toast.makeText(getApplicationContext(), "No Buddies found ", Toast.LENGTH_SHORT).show();
                            }
                    }
                });
                try {
//
                    latLng = new LatLng(location.getLatitude(),location.getLongitude());
                    mMap.addMarker(new MarkerOptions().position(latLng).title("Marker"));
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,13.2f));
                    mMap.addCircle(new CircleOptions().center(latLng).radius(RADIUS).strokeWidth(3F).strokeColor(Color.RED).fillColor(Color.argb(70,150,150,50)));
                    LatLng sydney = new LatLng(37.4142744,-122.07959771);
                    mMap.addMarker(new MarkerOptions().position(sydney).title("Person 2"));
//                    mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                }
                catch (SecurityException e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DIST, locationListener );

        }
        catch (SecurityException e)
        {
            e.printStackTrace();
        }

    }
}

/*
https://www.youtube.com/watch?v=qS1E-Vrk60E
https://www.youtube.com/watch?v=aE5f1tV5nU4
https://www.youtube.com/watch?v=9V0p_2lVoJo
https://www.youtube.com/watch?v=pSMa19vy8D8
 */